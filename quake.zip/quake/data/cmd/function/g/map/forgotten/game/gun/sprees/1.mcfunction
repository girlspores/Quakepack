tellraw @a[team=forgotten] [{"color":"aqua","selector":"@s "},{"color":"aqua","italic":true,"text":" is on a Killing Spree!"}]
tag @s add spree1