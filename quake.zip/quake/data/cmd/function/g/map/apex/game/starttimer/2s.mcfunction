tellraw @a[team=apex] [{"text":"The game starts in ","color":"yellow"},{"text":"2 ","color":"red"},{"text":"seconds!","color":"yellow"}]
execute as @a[team=apex] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100
