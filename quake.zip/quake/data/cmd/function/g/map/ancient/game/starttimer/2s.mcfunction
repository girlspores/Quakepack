tellraw @a[team=ancient] [{"text":"The game starts in ","color":"yellow"},{"text":"2 ","color":"red"},{"text":"seconds!","color":"yellow"}]
execute as @a[team=ancient] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 100
