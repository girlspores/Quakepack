tellraw @a[team=coldwar] [{"color":"aqua","selector":"@s "},{"color":"aqua","italic":true,"text":" is on a Rampage!"}]
tag @s add spree2